﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAS_Exception
{
    public class Exceptions1 : ApplicationException
    {
        public Exceptions1() : base()
        {

        }

        public Exceptions1(string message) : base(message)
        {

        }

        public Exceptions1(string message, Exception innerException)
            : base(innerException: innerException, message: message)
        {

        }
    }
}
