Create PROCEDURE [46008556].Submit
@Service_ID varchar(30),
@Date date,
@Owner_Name varchar(50),
@Contact_No varchar(10),
@Device_Type varchar(10),
@Serial_No varchar(15),
@Issue_Description varchar(20)
AS
BEGIN
	insert into [46008556].Lenovo_Service values(@Service_ID,@Date, @Owner_Name , @Contact_No,@Device_Type, @Serial_No, @Issue_Description)
END

---------------------------------------------------------------
Create PROCEDURE [46008556].getdetails
as
begin
select * from [46008556].Lenovo_Service
end




------------------------------------------------------------------------
use Training_19Sep19_Pune
go
drop TABLE [46008556].Lenovo_Service
CREATE TABLE [46008556].Lenovo_Service(
	[Service_ID] [varchar](30) NOT NULL,
	[Date] date not null,
	[Owner_Name] [varchar](50) NOT NULL,
	[Contact_No] [varchar](10) NOT NULL,
	[Device_Type] [varchar] (20) Not Null,
	[Serial_No] [Varchar](15)  NOT NULL,
	[Issue_Description] [varchar](20) Not null)


insert into [46008556].Lenovo_Service  values('SR1001','08/10/2019', 'Renu Sharma',
											  '9834121214','Mobile', '2311-1112-1125', 'Camera Not Working')