﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LSA_Entity;
using LSA_BAL;
using LAS_Exception;

namespace LSP_PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Getdetails();
        }

        private void Getdetails()
        {
            try
            {
                List<Details> objDetails = LsaBL.GetDetailsBL();
                if (objDetails != null)
                {
                    dgLenovo.ItemsSource = objDetails;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (Exceptions1 ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Submit()
        {
            try
            {
                string serviceId;
                string ownerName;
                DateTime date;
                string contactNo;
                string deviceType;
                string serialNo;
                string issueDescription;
                bool added;

                serviceId = txtServiceId1.Text;
                ownerName = txtOwnerName.Text;
                //date= DatePicker date
                contactNo = txtContact.Text;
                deviceType = cmbDevicetype.Text;
                serialNo = txtSerial.Text;
                issueDescription = txtIssue.Text;
                date = Convert.ToDateTime(dpDate.SelectedDate);
                Details det = new Details
                {
                    ServiceId = serviceId,
                    OwnerName = ownerName,
                    ContactNo = contactNo,
                    SerialNo = serialNo,
                    IssueDescription = issueDescription,
                    DeviceType = deviceType,
                    Date=date
                };
                added = LsaBL.SumitBL(det);
                if(added==true)
                {
                    MessageBox.Show("Service Request Added");
                }
                else
                {
                    MessageBox.Show("Service Request not Added");
                }
                

            }
            catch(Exceptions1 e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            Submit();
            Getdetails();
        }
    }
}
