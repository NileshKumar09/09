﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LSA_Entity
{
    public class Details
    {
        //private string serviceId;
        //private DateTime date;
        //private string ownerName;
        //private string contactNo;
        //private string deviceType;
        //private string serialNo;
        //private string issueDescription;

        public string ServiceId { get; set; }
        public DateTime Date { get; set; }
        public string OwnerName { get; set; }
        public string ContactNo { get; set; }
        public string DeviceType { get; set; }
        public string SerialNo { get; set; }
        public string IssueDescription { get; set; }
    }
}
