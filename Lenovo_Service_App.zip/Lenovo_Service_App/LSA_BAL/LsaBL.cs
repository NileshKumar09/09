﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LAS_Exception;
using LSA_DAL;
using LSA_Entity;
using System.Text.RegularExpressions;

namespace LSA_BAL
{
    public class LsaBL
    {
        private static bool Validation(Details d)
        {
            StringBuilder sb = new StringBuilder();
            bool validDetails = true;
            try
            {
                
                bool sid = Regex.IsMatch(d.ServiceId, "[S][R][0-9]{4}");
                if (!sid)
                {
                    sb.Append("ID length should be 6 and starts with SR" + Environment.NewLine);
                    validDetails = false;
                }
                bool con = Regex.IsMatch(d.ContactNo, "[7-9]{1}[0-9]{9}");
                if (!con)
                {
                    sb.Append("Number should starts with 7 or 8 or 9" + Environment.NewLine);
                    validDetails = false;
                }
                bool serno = Regex.IsMatch(d.SerialNo, "[0-9]{4}-[0-9]{4}-[0-9]{4}");
                if (!serno)
                {
                    sb.Append("Number format is XXXX-XXXX-XXXX" + Environment.NewLine);
                    validDetails = false;
                }
                if ((d.Date) > DateTime.Today)
                {
                    sb.Append("Service Date cannot be greater than Today");
                    validDetails = false;
                }
                if (validDetails == false)
                {
                    throw new Exceptions1(sb.ToString());
                }
                
            }
            catch(Exceptions1 e)
            {
                throw e;
            }
            return validDetails;
        }
        public static bool SumitBL(Details d)
        {
            bool adddedbl = false;
            if (Validation(d)==true)
            { 
            
            
            try
            {
                Details d1 = new Details();
                adddedbl = LsaDL.SubmitDL(d);
                return adddedbl;
            }
            catch(Exceptions1 e)
            {
                throw e;
            }
            }
            return adddedbl;
        }
        public static List<Details> GetDetailsBL()
        {
            List<Details> DetailList;
            try
            {
                
                DetailList = LsaDL.GetDetailsDL();
            }
            catch (Exceptions1 ex)
            {
                throw ex;
            }

            return DetailList;
        }
    }
}
