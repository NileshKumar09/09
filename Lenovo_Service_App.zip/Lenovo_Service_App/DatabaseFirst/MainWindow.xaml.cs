﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using LAS_Exception;
using LSA_Entity;

namespace DatabaseFirst
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Entities Service = new Entities();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnDisplay_Click(object sender, RoutedEventArgs e)
        {
            Display1();
        }
        private void Display1()
        {
            try
            {

                string deviceType = cmbDevicetype.Text;
                var getdetails = from b in Service.Lenovo_Service
                                 where b.Device_Type == deviceType
                                 select b;
                dgdetail.ItemsSource = getdetails.ToList();
            }
            catch (SqlException objSqlEx)
            {
                throw new Exception(objSqlEx.Message);
            }
        }
    }
}
