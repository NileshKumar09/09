﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using LAS_Exception;
using LSA_Entity;

namespace LSA_DAL
{
    public class LsaDL
    {

        public static bool SubmitDL(Details d1)
        {
            bool addeddl = true;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                                    ConfigurationManager.ConnectionStrings["LenovoService"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008556].Submit", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_serviceId = new SqlParameter("@Service_ID", d1.ServiceId);
                SqlParameter objSqlParam_date = new SqlParameter("@Date", d1.Date);
                SqlParameter objSqlParam_ownerName = new SqlParameter("@Owner_Name", d1.OwnerName);
                SqlParameter objSqlParam_contactNo = new SqlParameter("@Contact_No", d1.ContactNo); 
                SqlParameter objSqlParam_serialNo = new SqlParameter("@Serial_No", d1.SerialNo);
                SqlParameter objSqlParam_issueDes = new SqlParameter("@Issue_Description", d1.IssueDescription);
                SqlParameter objSqlParam_deviceType = new SqlParameter("@Device_Type", d1.DeviceType);

                //
                objCom.Parameters.Add(objSqlParam_serviceId);
                objCom.Parameters.Add(objSqlParam_date);
                objCom.Parameters.Add(objSqlParam_ownerName);
                objCom.Parameters.Add(objSqlParam_contactNo);
                objCom.Parameters.Add(objSqlParam_serialNo);
                objCom.Parameters.Add(objSqlParam_issueDes);
                objCom.Parameters.Add(objSqlParam_deviceType);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                addeddl = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Exceptions1(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return addeddl;
        }
        public static List<Details> GetDetailsDL()
        {
            List<Details> objDetailss = new List<Details>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["LenovoService"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008556].getdetails1", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Details objDetails = new Details();
                    objDetails.ServiceId = objDR[0].ToString();
                    objDetails.Date = Convert.ToDateTime(objDR[1].ToString());
                    objDetails.OwnerName = objDR[2].ToString();
                    objDetails.ContactNo = objDR[3].ToString();
                    objDetails.DeviceType = objDR[4].ToString();
                    objDetails.SerialNo =  objDR[5].ToString();
                    objDetails.IssueDescription = objDR[6].ToString();
                    objDetailss.Add(objDetails);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new Exceptions1(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objDetailss;
        }

    }
}
